function App() {
  return (
    <div>
      Edit me I'm famous
    </div>
  )
}

export default App
