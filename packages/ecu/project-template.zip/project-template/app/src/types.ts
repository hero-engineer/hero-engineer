/* ---
  Please do not delete this file
  as it is needed by the ecu core engine
--- */

export type Foo = string
