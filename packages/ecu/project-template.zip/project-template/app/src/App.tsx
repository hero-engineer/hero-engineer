/* --
  * IMPORTS START
-- */
import { Div } from 'ecu'

/* --
  * IMPORTS END
-- */
/* --
  * TYPES START
-- */
type AppPropsType = Record<string, never>
/* --
  * TYPES END
-- */

function App(props: AppPropsType) {
  return (
    <Div>
      Edit me I'm famous3
    </Div>
  )
}

export default App
