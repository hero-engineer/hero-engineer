/* --
  * IMPORTS START
-- */
import { Div } from 'ecu'

/* --
  * IMPORTS END
-- */
/* --
  * TYPES START
-- */
type AppPropsType = Record<string, never>
/* --
  * TYPES END
-- */
/* --
  * EMOJI START
-- */
/*
:cyclone:
*/
/* --
  * EMOJI END
-- */
/* --
  * DESCRIPTION START
-- */
/*
The app's entry point
*/
/* --
  * DESCRIPTION END
-- */

function App(props: AppPropsType) {
  return (
    <Div>
      Edit me I'm famous
    </Div>
  )
}

export default App
