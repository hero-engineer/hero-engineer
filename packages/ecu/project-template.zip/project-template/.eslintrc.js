module.exports = {
  extends: 'ecu',
}
